/* Bounded functional contrast, not a startup timing/guardVersion2 validation.
   Uses only readonly production acceptance, DOM activation and real W input. */
const need=(yes,why)=>{if(!yes)throw Error('notrace:'+why);};
const api=window.__addressAcceptance17b,host=window.__startupHost,expected={"graphics":"high","identity":{"mapId":"seversk","mapHash":"feccf579eb6402d7cdf1f6f29288843bf792b645d0cb81c1006a2aeb0f8f13c3","editsHash":"b6634c2b88dc68358aee22c1c9046b821ee55bbe9308f63ed747fd20a2357c32","sourceHash":"7c2b69b062fda7248d4a66d01207c216ccea9b9edf3f72614be4dd946e2a0fef","inputHash":"aaa7f2f0ecf627e74be8fe192c8f09fdcbf568f24ad3b259aae9ffc87af52d77"},"entry":{"path":"address-data/4531b47738693532d875a7dbb97633060ddd9fc0c04169d795ab3407dea1e6f2.addr","bytes":413028,"sha256":"4531b47738693532d875a7dbb97633060ddd9fc0c04169d795ab3407dea1e6f2"}};
const noTrace=()=>need(window.__startupTrace===undefined&&!window.__dlv,'trace/debug namespace appeared');
const ordinary=c=>{need(c.testTools===false&&c.firstControl===null,'test tools/control mark');need(c.district.current===0&&c.district.opened===1&&c.district.city===false&&c.district.partySeen===false&&c.district.pizzaIndex===0,'fresh district/pizzeria');need(c.graphics.preset==='high'&&c.graphics.device==='deck','high Deck slot');};
noTrace();need(api?.ready===true,'readonly acceptance unavailable');
need(location.search==='?mute'&&document.documentElement.lang==='ru','actual ordinary URL/language');
need(host?.environment?.productionQuery===true&&host.environment.deck===true&&host.seed===null&&host.cpuThrottle===1&&host.bootcpu===true,'host environment');
need(host.admission?.mode==='settled'&&host.admission.controlWaitMs===420000&&host.admission.movementWaitMs===30000,'settled allowance');
const before=api.capture();ordinary(before);
need(before.state==='title'&&!!window.__boot?.full&&!document.body.classList.contains('booting'),'untouched settled menu');
const visible=b=>b&&!b.closest('[hidden]')&&!b.disabled&&b.getBoundingClientRect().width>0&&getComputedStyle(b).visibility!=='hidden';
const card=document.querySelector('.crm-card[data-key="go"]'),go=card?.querySelector('.crm-cb');need(visible(go),'visible real Go missing');
let goClicks=0,dialogClicks=0;
if(!card.classList.contains('on')){go.click();goClicks++;await new Promise(r=>requestAnimationFrame(r));need(card.classList.contains('on'),'Go selection failed');}
go.click();goClicks++;
const deadline=performance.now()+host.admission.controlWaitMs;
while(performance.now()<deadline){
  noTrace();need(!document.querySelector('#cr-city')&&!document.querySelector('#cr-dpick:not([hidden])'),'unexpected mature UI');
  const root=document.querySelector('#dlg:not([hidden])'),yes=root?.querySelector('.dlg-yes');
  const button=visible(yes)?yes:Array.from(root?.querySelectorAll('button')||[]).find(visible);
  if(button){button.click();dialogClicks++;await wait(50);continue;}
  if(api.capture().state==='drive'&&!visible(root))break;
  await wait(50);
}
const ready=api.capture();ordinary(ready);need(ready.state==='drive'&&!visible(document.querySelector('#dlg:not([hidden])')),'real start/tutorial did not complete');
const position=ready.position;need(Number.isFinite(position.x)&&Number.isFinite(position.z),'position');
const movementStart=performance.now();
try{
  document.dispatchEvent(new KeyboardEvent('keydown',{key:'w',code:'KeyW',bubbles:true,cancelable:true}));
  do{await wait(50);}while(Math.hypot(api.capture().position.x-position.x,api.capture().position.z-position.z)<=.05&&performance.now()<movementStart+host.admission.movementWaitMs);
}finally{document.dispatchEvent(new KeyboardEvent('keyup',{key:'w',code:'KeyW',bubbles:true}));}
await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));
noTrace();need(location.search==='?mute','URL changed');
const after=api.capture();ordinary(after);
const moved=Math.hypot(after.position.x-position.x,after.position.z-position.z);need(moved>.05&&after.state==='drive','actual W movement');
const details=api.details(),input=details.input,provider=details.provider,preload=details.preload;
need(input?.eligible===true&&Object.keys(expected.identity).every(k=>input.identity?.[k]===expected.identity[k]),'full actual input identity');
need(input.descriptor?.version===2&&input.descriptor.profile==='fresh-v1'&&input.descriptor.query.normalization==='fresh-diagnostics-v1'&&input.descriptor.query.raw===''&&input.descriptor.query.entries.length===0&&input.descriptor.diagnosticQuery.raw==='?mute','normalized/diagnostic query');
need(details.preVisual?.phase==='before-city-syncBuild'&&details.preVisual.lateWorkStarted===false&&['houses','generatedDoors','spots'].every(k=>details.preVisual.before[k]===0&&details.preVisual.after[k]===0)&&details.preVisual.before.rawEntrances===details.preVisual.after.rawEntrances&&details.preVisual.inputHash===expected.identity.inputHash,'previsual barrier');
need(details.status?.phase==='private-ready'&&provider?.phase==='sealed'&&provider.privateReady===true&&provider.published===true&&provider.fatal===false&&provider.auditRetained===false,'sealed provider');
need(preload?.phase==='consumed'&&preload.consumed===true&&preload.held===false&&preload.selectedGraphics==='high'&&preload.catalogVersion===2&&preload.wireHash===expected.entry.sha256&&preload.wireBytes===expected.entry.bytes,'consumed high wire');
const early=details.early?.queries,current=api.queries();
need(early&&current&&JSON.stringify(early.queriesExact)===JSON.stringify(current.queriesExact)&&JSON.stringify(early.counts)===JSON.stringify(current.counts)&&early.sourceRawSha256===current.sourceRawSha256&&Object.keys(expected.identity).every(k=>early.identity[k]===expected.identity[k]&&current.identity[k]===expected.identity[k]),'early private vs actual legacy query proof');
const crashes=api.crashes();need(Array.isArray(crashes)&&crashes.length===0,'crash log');
const bootstrap=window.__startupBootGuard;need(bootstrap?.markerWrites>0&&bootstrap.bootAbsentAtMarker===true&&bootstrap.earlyBootSeen===false,'bootstrap order');
return{ok:true,kind:'ordinary-address-no-trace-functional-contrast',scope:'One functional contrast only; no startup latency, first.control, guardVersion2 or support-ready guard observation.',tracePresent:false,debugNamespace:false,testTools:false,firstControl:null,supportGuardObserved:false,conditions:{url:location.href,language:document.documentElement.lang,physicalDeck:false,graphics:after.graphics,admission:'settled'},menu:{state:before.state,bootFull:!!window.__boot.full},movement:{moved,goClicks,dialogClicks,afterState:after.state,position:after.position},district:after.district,address:{identity:input.identity,preVisual:details.preVisual,provider,preload,earlyQueryProof:{matched:true,counts:current.counts,sourceRawSha256:current.sourceRawSha256}},bootstrap,crashCount:crashes.length};
