import fs from 'node:fs';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {createRequire} from 'node:module';
import {finished} from 'node:stream/promises';
const repo='/Users/andrewboev/Desktop/not-work/delivery',out='/tmp/bird-address-ordinary-final-1102';
const {captureSource,captureBuild,sha256}=await import(path.join(repo,'tools/land-package-files.mjs'));
const {validateStartupReport}=await import(path.join(repo,'tools/startup-report.mjs'));
const electron=createRequire(path.join(repo,'package.json'))('electron'),asar=createRequire(path.join(repo,'package.json'))('@electron/asar');
const prepared=JSON.parse(fs.readFileSync(path.join(out,'preparation.json')));if(!prepared.ok)throw Error('preparation must pass');
const journal={source:captureSource(repo),runs:[],startedAt:new Date().toISOString()};
const save=()=>fs.writeFileSync(path.join(out,'consumer-protocol.json'),JSON.stringify(journal,null,2));
const need=(yes,why)=>{if(!yes)throw Error(why);};
const env={...process.env,BUILD_VERSION:'0.33.12',BIRD_ADDRESS_DATA_DIR:path.join(out,'package')};delete env.BIRD_LAND_DATA_DIR;delete env.BIRD_EDITOR;
async function run(label,command,args,limit=950000){
 const row={label,argv:[command,...args],env:{BUILD_VERSION:env.BUILD_VERSION,BIRD_ADDRESS_DATA_DIR:env.BIRD_ADDRESS_DATA_DIR},status:'running',processStatus:null,signal:null};journal.runs.push(row);save();
 const stdout=fs.createWriteStream(path.join(out,label+'.stdout.log'),{flags:'wx'}),stderr=fs.createWriteStream(path.join(out,label+'.stderr.log'),{flags:'wx'});
 const child=spawn(command,args,{cwd:repo,env,stdio:['ignore','pipe','pipe']});child.stdout.pipe(stdout);child.stderr.pipe(stderr);row.pid=child.pid;save();const timer=setTimeout(()=>child.kill('SIGKILL'),limit);
 const status=await new Promise(resolve=>{child.once('error',e=>{row.error=String(e);resolve({code:null,signal:null});});child.once('close',(code,signal)=>resolve({code,signal}));});clearTimeout(timer);await Promise.all([finished(stdout),finished(stderr)]);
 row.processStatus=status.code;row.signal=status.signal;row.status='returned';row.stdoutSha256=sha256(fs.readFileSync(path.join(out,label+'.stdout.log')));row.stderrSha256=sha256(fs.readFileSync(path.join(out,label+'.stderr.log')));save();need(status.code===0&&!status.signal&&!row.error,label+' process');return row;
}
try{
 const dist=path.join(out,'production-steam');await run('consumer-build',process.execPath,[path.join(repo,'node_modules/vite/bin/vite.js'),'build','--mode','steam','--outDir',dist],300000);journal.build=captureBuild(dist);save();
 for(const variant of ['reader','generated']){
 const raw=path.join(out,'consumer-'+variant+'.json');
 await run('consumer-'+variant,electron,[path.join(repo,'tools/probe.cjs'),'--mode=steam','--dir='+dist,'--startup-trace','--startup-cold','--startup-no-lang','--startup-deck','--startup-session=ordinary-'+variant+'-1102','--startup-fixture='+path.join(out,'fresh-high-1/fixture.json'),'--fresh','--early','--size=deck','--cpu=1','--bootcpu','--init-script='+(variant==='reader'?path.join(out,'early-queries-high-init.js'):path.join(repo,'tools/probe-checks/startup-bootstrap-observe.js')),'--q=addressclosure17b'+(variant==='generated'?'&addresspackage17b=0':''),'--eval='+path.join(out,'consumer-eval.js'),'--bootwait=360','--timeout=900','--max=0','--errors','--report='+raw]);
 const value=JSON.parse(fs.readFileSync(raw));const gate=validateStartupReport(value,{expectedDistrict:0,requireDistrict:true,requireGuardV2:true});need(gate.ok,variant+' startup '+gate.reasons);journal[variant]={raw,sha256:sha256(fs.readFileSync(raw)),gate};save();
 }
 const original=JSON.parse(fs.readFileSync(path.join(out,'fresh-high-1/raw.json'))),reader=JSON.parse(fs.readFileSync(journal.reader.raw)),generated=JSON.parse(fs.readFileSync(journal.generated.raw));
 for(const key of ['menuExact','fixedQueriesExact','exactQueryTables'])for(const [label,value]of [['reader',reader],['generated',generated]])need(JSON.stringify(value.result.addressClosure[key])===JSON.stringify(original.result.addressClosure[key]),label+' exact '+key);
 const stage=path.join(out,'asar-stage');fs.mkdirSync(path.join(stage,'dist'),{recursive:true});fs.cpSync(dist,path.join(stage,'dist/steam'),{recursive:true});const archive=path.join(out,'candidate.asar');await asar.createPackage(stage,archive);journal.archive={file:archive,bytes:fs.statSync(archive).size,sha256:sha256(fs.readFileSync(archive))};save();
 await run('consumer-asar-verify',process.execPath,[path.join(repo,'tools/address-package-verify-asar.mjs'),'--asar='+archive,'--dir='+dist,'--report='+path.join(out,'actual-asar.json')]);
 need(JSON.stringify(captureSource(repo))===JSON.stringify(journal.source),'source changed');journal.ok=true;save();console.log(JSON.stringify({ok:true,out,source:journal.source.base,archive:journal.archive}));
}catch(e){journal.ok=false;journal.failure=String(e.stack||e);save();console.error(journal.failure);process.exitCode=1;}
