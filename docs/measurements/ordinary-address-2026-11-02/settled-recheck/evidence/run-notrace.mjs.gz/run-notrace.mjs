import fs from 'node:fs';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {createRequire} from 'node:module';
import {finished} from 'node:stream/promises';
const repo='/Users/andrewboev/Desktop/not-work/delivery',out='/tmp/bird-address-ordinary-final-1102';
const {captureSource,captureBuild,sha256}=await import(path.join(repo,'tools/land-package-files.mjs'));
const {validateStartupReport}=await import(path.join(repo,'tools/startup-report.mjs'));
const electron=createRequire(path.join(repo,'package.json'))('electron'),asar=createRequire(path.join(repo,'package.json'))('@electron/asar');
const prepared=JSON.parse(fs.readFileSync(path.join(out,'preparation.json')));if(!prepared.ok)throw Error('preparation must pass');
const journal={source:captureSource(repo),runs:[],startedAt:new Date().toISOString()};
const save=()=>fs.writeFileSync(path.join(out,'notrace-protocol.json'),JSON.stringify(journal,null,2));
const need=(yes,why)=>{if(!yes)throw Error(why);};
const env={...process.env,BUILD_VERSION:'0.33.12',BIRD_ADDRESS_DATA_DIR:path.join(out,'package')};delete env.BIRD_LAND_DATA_DIR;delete env.BIRD_EDITOR;
async function run(label,command,args,limit=950000){
 const row={label,argv:[command,...args],env:{BUILD_VERSION:env.BUILD_VERSION,BIRD_ADDRESS_DATA_DIR:env.BIRD_ADDRESS_DATA_DIR},status:'running',processStatus:null,signal:null};journal.runs.push(row);save();
 const stdout=fs.createWriteStream(path.join(out,label+'.stdout.log'),{flags:'wx'}),stderr=fs.createWriteStream(path.join(out,label+'.stderr.log'),{flags:'wx'});
 const child=spawn(command,args,{cwd:repo,env,stdio:['ignore','pipe','pipe']});child.stdout.pipe(stdout);child.stderr.pipe(stderr);row.pid=child.pid;save();const timer=setTimeout(()=>child.kill('SIGKILL'),limit);
 const status=await new Promise(resolve=>{child.once('error',e=>{row.error=String(e);resolve({code:null,signal:null});});child.once('close',(code,signal)=>resolve({code,signal}));});clearTimeout(timer);await Promise.all([finished(stdout),finished(stderr)]);
 row.processStatus=status.code;row.signal=status.signal;row.status='returned';row.stdoutSha256=sha256(fs.readFileSync(path.join(out,label+'.stdout.log')));row.stderrSha256=sha256(fs.readFileSync(path.join(out,label+'.stderr.log')));save();need(status.code===0&&!status.signal&&!row.error,label+' process');return row;
}
try{
 const raw=path.join(out,'notrace-raw.json');
 await run('notrace',electron,[path.join(repo,'tools/probe.cjs'),'--mode=steam','--dir='+path.join(out,'candidate.asar/dist/steam'),'--startup-trace','--startup-cold','--startup-production-query','--startup-deck','--startup-session=ordinary-notrace-1102','--startup-fixture='+path.join(out,'fresh-high-1/fixture.json'),'--fresh','--startup-admission=settled','--size=deck','--cpu=1','--bootcpu','--init-script='+path.join(out,'notrace-init.js'),'--eval='+path.join(out,'notrace-eval.js'),'--bootwait=1200','--timeout=1740','--max=0','--errors','--report='+raw],1800000);
 const value=JSON.parse(fs.readFileSync(raw));need(value.ok===true&&value.result?.ok===true&&!value.evalErr&&value.uncaught===0&&value.errors?.length===0,'notrace envelope');
 need(JSON.stringify(captureSource(repo))===JSON.stringify(journal.source),'source changed');journal.raw={file:raw,bytes:fs.statSync(raw).size,sha256:sha256(fs.readFileSync(raw))};journal.harness=['notrace-init.js','notrace-eval.js'].map(file=>({file,sha256:sha256(fs.readFileSync(path.join(out,file)))}));journal.ok=true;save();console.log(JSON.stringify({ok:true,scope:value.result.scope,moved:value.result.movement.moved}));
}catch(e){journal.ok=false;journal.failure=String(e.stack||e);save();console.error(journal.failure);process.exitCode=1;}
